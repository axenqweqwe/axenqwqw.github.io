---
title: "Grabber 7.7.1 released"
date: 2022-01-08 16:57 +0100
categories: release
---


Grabber 7.7.1 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.7.1>