---
title: "Grabber 7.8.1 released"
date: 2022-04-20 23:34 +0100
categories: release
---


Grabber 7.8.1 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.8.1>