---
title: "Grabber 7.6.2 released"
date: 2021-09-02 18:35 +0200
categories: release
---


Grabber 7.6.2 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.6.2>