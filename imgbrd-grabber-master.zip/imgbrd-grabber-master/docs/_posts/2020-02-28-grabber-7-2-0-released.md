---
title: "Grabber 7.2.0 released"
date: 2020-02-28 20:21:00 +0100
categories: release
---


Grabber 7.2.0 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.2.0>