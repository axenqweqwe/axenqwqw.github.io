---
title: "Grabber 7.4.2 released"
date: 2021-03-13 15:40:00 +0100
categories: release
---


Grabber 7.4.2 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.4.2>