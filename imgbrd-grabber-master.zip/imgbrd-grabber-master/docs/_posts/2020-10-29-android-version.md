---
title: "Android version"
date: 2020-10-29 21:20:00 +0100
categories: android
---


Hey everyone!

&nbsp;

For those that might not follow the project closely on Github, there's a new Android version of Grabber that's under active development.

<!--more-->

![Screenshot]({{ '/assets/img/blog/android-version.png' | relative_url }})

You can find more details here, such as screenshots, status, roadmap, etc:  
[Bionus/imgbrd-grabber#2147](https://github.com/Bionus/imgbrd-grabber/issues/2147)

Or if you just want to download it, here's the link!  
[Grabber_nightly.apk](https://github.com/Bionus/imgbrd-grabber/releases/download/nightly/Grabber_nightly.apk)

It's still rough around the edges, but the basics are there! Feel free to comment here or on Github if you have any feedback, suggestions, requests, etc!

&nbsp;

Best,  
Bionus