---
title: "Grabber 7.3.2 released"
date: 2020-08-01 23:15:00 +0200
categories: release
---


Grabber 7.3.2 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.3.2>