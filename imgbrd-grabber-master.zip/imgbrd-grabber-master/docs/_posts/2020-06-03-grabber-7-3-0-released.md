---
title: "Grabber 7.3.0 released"
date: 2020-06-03 17:12:00 +0200
categories: release
---


Grabber 7.3.0 has been released.

The list of changes and download links can be found on Github:  
<https://github.com/Bionus/imgbrd-grabber/releases/tag/v7.3.0>