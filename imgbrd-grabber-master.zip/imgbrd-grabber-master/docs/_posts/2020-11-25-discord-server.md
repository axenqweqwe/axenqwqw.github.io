---
title: "Discord server"
date: 2020-11-25 23:25:00 +0100
---


Hey everyone!

&nbsp;

Multiple people asked for it, and since very few people were using the Gitter server, I've decided to move the chat/discussion server to Discord. I'll still be on Gitter for a while, but it will eventually be closed to avoid having two places for the same thing.

<!--more-->

Here is the invite link:  
<https://discord.gg/pWnY5eW3rz>

Try not to use it for reporting things you believe to be bugs or huge suggestions, unless you want them to be lost or forgotten within the discussion flow (for this, you should keep using [Github issues](https://github.com/Bionus/imgbrd-grabber/issues) as usual). The main goal is discussion about Grabber and quick questions that might not warrant a big ticket.

&nbsp;

Best,  
Bionus