---
title: E-Hentai
---


# E-Hentai

## Search syntax

* `tag1 tag2`: basic tag search
* `cats:NUMBER`: the `f_cats` URL parameter used to filter by category (default: `0`)