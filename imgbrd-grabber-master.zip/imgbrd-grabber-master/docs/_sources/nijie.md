---
title: Nijie
---


# Nijie

## Search syntax

* `tag1 tag2`: basic tag search
* `user:USER_ID`: fetch art from a given user
* `type:{images", "doujin", "bookmarks}`: what kind of works to load when searching an user (default: `images`)