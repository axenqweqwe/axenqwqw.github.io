---
title: DeviantArt
---


# DeviantArt

Whatever URL is entered when adding a site with this source, it will be overriden by:
* <https://backend.deviantart.com/>

## Search syntax

<https://www.deviantartsupport.com/en/article/are-there-any-tricks-to-narrowing-down-a-search-on-deviantart>

In addition:
* `order:ORDER`: how to sort results (possible values: "newest", "popular-8-hours", "popular-24-hours", "popular-3-days", "popular-1-week", "popular-1-month", "popular-all-time")