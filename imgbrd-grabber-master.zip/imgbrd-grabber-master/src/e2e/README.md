# End-to-end checker

Tool to call all APIs of every site of every source, showing an easy-to-read summary. Useful to check the status of all sources and their Grabber parser.

[![Screenshot](resources/screenshot.png)](resources/screenshot.png)