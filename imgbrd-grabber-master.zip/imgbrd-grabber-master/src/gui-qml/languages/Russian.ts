<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru" sourcelanguage="en">
  <context>
    <name>AboutSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="11"/>
      <source>About</source>
      <translation>О программе</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="14"/>
      <source>Version</source>
      <translation>Версия</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="21"/>
      <source>Check for updates</source>
      <translation>Проверять обновления</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="26"/>
      <source>See project on Github</source>
      <translation>Проект Github</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="31"/>
      <source>Report an issue</source>
      <translation>Сообщить об ошибке</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="38"/>
      <source>Author</source>
      <translation>Автор</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="41"/>
      <source>Email</source>
      <translation>Email</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="47"/>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="70"/>
      <source>Github</source>
      <translation>GitHub</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="55"/>
      <source>Donate</source>
      <translation>Пожертвовать</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="58"/>
      <source>Patreon</source>
      <translation>Patreon</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="64"/>
      <source>Paypal</source>
      <translation>PayPal</translation>
    </message>
  </context>
  <context>
    <name>AddSourceScreen</name>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="24"/>
      <source>Add new source</source>
      <translation>Добавить новый источник</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="34"/>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="43"/>
      <source>Type</source>
      <translation>Тип</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="53"/>
      <source>URL</source>
      <translation>Адрес</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="63"/>
      <source>HTTPS</source>
      <translation>HTTPS</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="74"/>
      <source>Add</source>
      <translation>Добавить</translation>
    </message>
  </context>
  <context>
    <name>AdvancedSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="13"/>
      <source>Updates</source>
      <translation>Обновления</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="16"/>
      <source>Check for updates interval</source>
      <translation>Интервал проверки обновлений</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Every time</source>
      <translation>Всегда</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a day</source>
      <translation>Ежедневно</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a week</source>
      <translation>Еженедельно</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a month</source>
      <translation>Ежемесячно</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Never</source>
      <translation>Никогда</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="25"/>
      <source>Backup</source>
      <translation>Резервное копирование</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="28"/>
      <source>Export settings</source>
      <translation>Экспорт настроек</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="29"/>
      <source>Backup the app settings.ini file on your device.</source>
      <translation>Резервное копирование файла приложения settings.ini на ваше устройство.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="37"/>
      <source>Please choose a directory</source>
      <translation>Пожалуйста, выберите каталог</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="45"/>
      <source>Import settings</source>
      <translation>Импорт настроек</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="46"/>
      <source>Import the app settings.ini from an existing file.</source>
      <translation>Импорт settings.ini приложения из существующего файла.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="54"/>
      <source>Please choose a file</source>
      <translation>Пожалуйста, выберите файл</translation>
    </message>
  </context>
  <context>
    <name>AppearanceSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="11"/>
      <source>Appearance</source>
      <translation>Оформление</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="14"/>
      <source>Theme</source>
      <translation>Тема</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="21"/>
      <source>Primary color</source>
      <translation>Основной цвет</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="26"/>
      <source>Accent color</source>
      <translation>Дополнительный цвет</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="33"/>
      <source>Image</source>
      <translation>Изображение</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="36"/>
      <source>Background color</source>
      <translation>Цвет фона</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="41"/>
      <source>Tags</source>
      <translation>Теги</translation>
    </message>
  </context>
  <context>
    <name>AppearanceTagsSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="11"/>
      <source>Tags</source>
      <translation>Теги</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="14"/>
      <source>Artists</source>
      <translation>Художники</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="19"/>
      <source>Circle</source>
      <translation>Круг</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="24"/>
      <source>Series</source>
      <translation>Серии</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="29"/>
      <source>Characters</source>
      <translation>Персонажи</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="34"/>
      <source>Species</source>
      <translation>Вид/раса</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="39"/>
      <source>Metas</source>
      <translation>Мета</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="44"/>
      <source>Models</source>
      <translation>Модели</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="49"/>
      <source>Generals</source>
      <translation>Общие</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="54"/>
      <source>Favorites</source>
      <translation>Избранное</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="59"/>
      <source>Kept for later</source>
      <translation>Оставить на потом</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="64"/>
      <source>Blacklisted</source>
      <translation>В чёрном списке</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="69"/>
      <source>Ignored</source>
      <translation>Игнорируемые</translation>
    </message>
  </context>
  <context>
    <name>BlacklistSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="11"/>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="14"/>
      <source>Blacklist</source>
      <translation>Чёрный список</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="15"/>
      <source>One line per blacklist. Multiple tags make an 'AND' condition.</source>
      <translation>Один на строку в чёрном списке. Несколько тегов составляют логический оператор «И».</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="20"/>
      <source>Hide blacklisted</source>
      <translation>Скрыть чёрный список</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="21"/>
      <source>Hide blacklisted images from the results.</source>
      <translation>Скрыть чёрный список изображений из результатов.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="26"/>
      <source>Download blacklisted</source>
      <translation>Скачать в чёрном списке</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="27"/>
      <source>Download blacklisted images during batch downloads.</source>
      <translation>Скачивайте изображения из чёрного списка при пакетной загрузке.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="34"/>
      <source>Tagging</source>
      <translation>Тегирование</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="37"/>
      <source>Removed tags</source>
      <translation>Удалённые теги</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="38"/>
      <source>These won't be taken into account when saving the image.</source>
      <translation>Эти теги не будут учтены при сохранении изображения.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="43"/>
      <source>Ignored tags</source>
      <translation>Игнорируемые теги</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="44"/>
      <source>One per line. Their tag type will be reset to the default.</source>
      <translation>По одному на строку. Их тип тегов будет сброшен до значения по умолчанию.</translation>
    </message>
  </context>
  <context>
    <name>FavoritesScreen</name>
    <message>
      <location filename="../src/components/FavoritesScreen.qml" line="22"/>
      <source>Favorites</source>
      <translation>Избранное</translation>
    </message>
  </context>
  <context>
    <name>FolderSetting</name>
    <message>
      <location filename="../src/components/settings/items/FolderSetting.qml" line="29"/>
      <source>Please choose a directory</source>
      <translation>Пожалуйста, выберите папку</translation>
    </message>
  </context>
  <context>
    <name>ImageLoader</name>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="155"/>
      <source>File is too big to be displayed.</source>
      <translation>Файл слишком большой для отображения.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="158"/>
      <source>Image not found.</source>
      <translation>Изображение не найдено.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="161"/>
      <source>Error loading the image.</source>
      <translation>Ошибка при загрузке изображения.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="164"/>
      <source>Error saving the image.</source>
      <translation>Ошибка при сохранении изображения.</translation>
    </message>
  </context>
  <context>
    <name>ImageScreen</name>
    <message>
      <location filename="../src/components/ImageScreen.qml" line="71"/>
      <source>Image</source>
      <translation>Изображение</translation>
    </message>
  </context>
  <context>
    <name>InterfaceSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="11"/>
      <source>Interface</source>
      <translation>Интерфейс</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="14"/>
      <source>Language</source>
      <translation>Язык</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="23"/>
      <source>Search results</source>
      <translation>Результаты поиска</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="26"/>
      <source>Columns (portrait)</source>
      <translation>Столбцы (портрет)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="33"/>
      <source>Columns (landscape)</source>
      <translation>Строки (ландшафт)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="40"/>
      <source>Layout type</source>
      <translation>Тип шаблона</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="47"/>
      <source>Grid ratio</source>
      <translation>Соотношение сетки</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="55"/>
      <source>Thumbnail fill mode</source>
      <translation>Режим заполнения миниатюр</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="63"/>
      <source>Spaced grid</source>
      <translation>Разнесённая сетка</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="70"/>
      <source>Rounded grid</source>
      <translation>Скруглённая сетка</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="71"/>
      <source>Slightly round thumbnails.</source>
      <translation>Немного округляет миниатюры.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="78"/>
      <source>Image viewer</source>
      <translation>Просмотрщик изображений</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="81"/>
      <source>Load samples</source>
      <translation>Загрузить образцы</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="82"/>
      <source>Load sample-sized versions of the images by default if available.</source>
      <translation>По умолчанию загружать изображения, уменьшенного размера, если возможно.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="87"/>
      <source>Buttons at the bottom</source>
      <translation>Кнопки в нижней части</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="88"/>
      <source>Move the action buttons to the bottom of the screen.</source>
      <translation>Поместить кнопки действий в нижней части экрана.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="95"/>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="98"/>
      <source>Confirm exit</source>
      <translation>Подтвердите выход</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="99"/>
      <source>Show a confirmation dialog before exiting.</source>
      <translation>Показывать подтверждение перед выходом.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="104"/>
      <source>Double tap to exit</source>
      <translation>Нажмите дважды, чтобы выйти</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="105"/>
      <source>Tap back button twice to exit.</source>
      <translation>Нажмите кнопку назад дважды, чтобы выйти.</translation>
    </message>
  </context>
  <context>
    <name>KeyValueSetting</name>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="63"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="76"/>
      <source>Add</source>
      <translation>Добавить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="85"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="114"/>
      <source>Key</source>
      <translation>Ключ</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="93"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="122"/>
      <source>Value</source>
      <translation>Значение</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="105"/>
      <source>Edit</source>
      <translation>Изменить</translation>
    </message>
  </context>
  <context>
    <name>LogScreen</name>
    <message>
      <location filename="../src/components/LogScreen.qml" line="18"/>
      <source>Log</source>
      <translation>Журнал</translation>
    </message>
  </context>
  <context>
    <name>MainDrawer</name>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="105"/>
      <source>Search</source>
      <translation>Поиск</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="111"/>
      <source>Favorites</source>
      <translation>Избранное</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="117"/>
      <source>Log</source>
      <translation>Журнал</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="141"/>
      <source>Settings</source>
      <translation>Настройки</translation>
    </message>
  </context>
  <context>
    <name>NetworkSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="11"/>
      <source>Proxy</source>
      <translation>Прокси</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="14"/>
      <source>Enable proxy</source>
      <translation>Включить прокси</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="19"/>
      <source>Use system-wide proxy settings</source>
      <translation>Использовать системные настройки прокси</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="25"/>
      <source>Type</source>
      <translation>Тип</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="33"/>
      <source>Host</source>
      <translation>Хост</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="39"/>
      <source>Port</source>
      <translation>Порт</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="46"/>
      <source>Username</source>
      <translation>Имя пользователя</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="52"/>
      <source>Password</source>
      <translation>Пароль</translation>
    </message>
  </context>
  <context>
    <name>SaveSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="11"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="14"/>
      <source>Folder</source>
      <translation>Папка</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="19"/>
      <source>Filename</source>
      <translation>Имя файла</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="24"/>
      <source>Tags separator</source>
      <translation>Разделитель тегов</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="29"/>
      <source>Replace spaces by underscores</source>
      <translation>Заменять пробелы на подчёркивания</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="34"/>
      <source>Replace JPEG by JPG</source>
      <translation>Заменить JPEG на JPG</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="35"/>
      <source>If the image's extension is ".jpeg", it will be replaced by ".jpg".</source>
      <translation>Если расширение файла содержит «.jpeg», то оно будет заменено на «.jpg».</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="42"/>
      <source>Duplicate management</source>
      <translation>Управление дубликатами</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="45"/>
      <source>If a file already exists globally</source>
      <translation>Если файл уже существует где-либо</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Copy</source>
      <translation>Копировать</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Move</source>
      <translation>Переместить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Don't save</source>
      <translation>Не скачивать</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="52"/>
      <source>If it's in the same directory</source>
      <translation>Если это есть в той же папке</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="59"/>
      <source>Keep deleted files in the MD5 list</source>
      <translation>Сохранять удаленные файлы в списке MD5</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="66"/>
      <source>Tags</source>
      <translation>Теги</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="71"/>
      <source>Artist</source>
      <translation>Автор</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="78"/>
      <source>Copyright</source>
      <translation>Авторское право</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="85"/>
      <source>Character</source>
      <translation>Персонаж</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="92"/>
      <source>Model</source>
      <translation>Модель</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="99"/>
      <source>Photo set</source>
      <translation>Фотосет</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="106"/>
      <source>Species</source>
      <translation>Вид/Раса</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="113"/>
      <source>Meta</source>
      <translation>Мета</translation>
    </message>
  </context>
  <context>
    <name>SearchScreen</name>
    <message>
      <location filename="../src/components/SearchScreen.qml" line="50"/>
      <source>Search...</source>
      <translation>Поиск...</translation>
    </message>
    <message>
      <location filename="../src/components/SearchScreen.qml" line="176"/>
      <source>Sources</source>
      <translation>Источники</translation>
    </message>
  </context>
  <context>
    <name>SettingsScreen</name>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="31"/>
      <source>Settings</source>
      <translation>Настройки</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="49"/>
      <source>Interface</source>
      <translation>Интерфейс</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="54"/>
      <source>Appearance</source>
      <translation>Оформление</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="59"/>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="64"/>
      <source>Sources</source>
      <translation>Источники</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="69"/>
      <source>Blacklist</source>
      <translation>Чёрный список</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="74"/>
      <source>Network</source>
      <translation>Сеть</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="79"/>
      <source>Advanced</source>
      <translation>Дополнительно</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="84"/>
      <source>About</source>
      <translation>О программе</translation>
    </message>
  </context>
  <context>
    <name>SourceSettingsScreen</name>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="85"/>
      <source>General</source>
      <translation>Основные</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="88"/>
      <source>Name</source>
      <translation>Имя</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="97"/>
      <source>HTTPS</source>
      <translation>HTTPS</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="98"/>
      <source>Use a secure connection.</source>
      <translation>Использовать безопасное соединение.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="109"/>
      <source>Login</source>
      <translation>Вход</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="118"/>
      <source>Type</source>
      <translation>Тип</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="158"/>
      <source>API order</source>
      <translation>Через API</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="167"/>
      <source>Use default API order</source>
      <translation>Использовать API по умолчанию</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="172"/>
      <source>Source 1</source>
      <translation>Источник 1</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="184"/>
      <source>Source 2</source>
      <translation>Источник 2</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="196"/>
      <source>Source 3</source>
      <translation>Источник 3</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="208"/>
      <source>Source 4</source>
      <translation>Источник 4</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="222"/>
      <source>Download</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="236"/>
      <source>Interval (image)</source>
      <translation>Интервал (изображения)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="246"/>
      <source>Interval (page)</source>
      <translation>Интервал (страница)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="256"/>
      <source>Interval (details)</source>
      <translation>Интервал (подробности)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="266"/>
      <source>Interval (error)</source>
      <translation>Интервал (ошибка)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="278"/>
      <source>Cookies</source>
      <translation>Куки</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="305"/>
      <source>Headers</source>
      <translation>Заголовки</translation>
    </message>
  </context>
  <context>
    <name>SourcesScreen</name>
    <message>
      <location filename="../src/components/SourcesScreen.qml" line="26"/>
      <source>Sources selection</source>
      <translation>Выбор источников</translation>
    </message>
  </context>
  <context>
    <name>SourcesSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="11"/>
      <source>API order</source>
      <translation>Через API</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="14"/>
      <source>Source 1</source>
      <translation>Источник 1</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="21"/>
      <source>Source 2</source>
      <translation>Источник 2</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="28"/>
      <source>Source 3</source>
      <translation>Источник 3</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="35"/>
      <source>Source 4</source>
      <translation>Источник 4</translation>
    </message>
  </context>
  <context>
    <name>TagSaveSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="16"/>
      <source>If empty</source>
      <translation>Если пусто</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="24"/>
      <source>Separator</source>
      <translation>Разделитель</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="32"/>
      <source>Sort</source>
      <translation>Сортировать</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="42"/>
      <source>If more than n tags</source>
      <translation>Если больше чем n тегов</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="56"/>
      <source>Action</source>
      <translation>Действие</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="63"/>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="72"/>
      <source>Keep n tags</source>
      <translation>Оставить n тегов</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="81"/>
      <source>Then add</source>
      <translation>Затем добавить</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="90"/>
      <source>Replace all tags by</source>
      <translation>Заменить все теги на</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="100"/>
      <source>Use shortest if possible</source>
      <translation>Использовать самые короткие теги если возможно</translation>
    </message>
  </context>
  <context>
    <name>main-screen</name>
    <message>
      <location filename="../src/main-screen.qml" line="47"/>
      <source>Through URL</source>
      <translation>По адресу</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="48"/>
      <source>HTTP Basic</source>
      <translation>Базовый HTTP</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="49"/>
      <source>GET</source>
      <translation>GET</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="50"/>
      <source>POST</source>
      <translation>POST</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="51"/>
      <source>OAuth 1</source>
      <translation>OAuth 1</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="52"/>
      <source>OAuth 2</source>
      <translation>OAuth 2</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="55"/>
      <source>Username</source>
      <translation>Имя пользователя</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="56"/>
      <source>User ID</source>
      <translation>ИД пользователя</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="57"/>
      <source>Password</source>
      <translation>Пароль</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="58"/>
      <source>Salt</source>
      <translation>Соль</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="59"/>
      <source>API key</source>
      <translation>Ключ API</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="77"/>
      <source>Update available</source>
      <translation>Доступно обновление</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="130"/>
      <source>Do you want to exit?</source>
      <translation>Вы действительно хотите выйти?</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="144"/>
      <source>Don't ask again</source>
      <translation>Больше не спрашивать</translation>
    </message>
  </context>
</TS>
