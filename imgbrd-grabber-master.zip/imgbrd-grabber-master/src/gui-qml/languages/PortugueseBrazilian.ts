<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt-BR" sourcelanguage="en">
  <context>
    <name>AboutSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="11"/>
      <source>About</source>
      <translation>Sobre</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="14"/>
      <source>Version</source>
      <translation>Versão</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="21"/>
      <source>Check for updates</source>
      <translation>Verificar se há atualizações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="26"/>
      <source>See project on Github</source>
      <translation>Ver o projeto no Github</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="31"/>
      <source>Report an issue</source>
      <translation>Reportar um erro</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="38"/>
      <source>Author</source>
      <translation>Autor</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="41"/>
      <source>Email</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="47"/>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="70"/>
      <source>Github</source>
      <translation>Github</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="55"/>
      <source>Donate</source>
      <translation>Doar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="58"/>
      <source>Patreon</source>
      <translation>Patreon</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AboutSettingsPage.qml" line="64"/>
      <source>Paypal</source>
      <translation>Paypal</translation>
    </message>
  </context>
  <context>
    <name>AddSourceScreen</name>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="24"/>
      <source>Add new source</source>
      <translation>Adicionar nova fonte</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="34"/>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="43"/>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="53"/>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="63"/>
      <source>HTTPS</source>
      <translation>HTTPS</translation>
    </message>
    <message>
      <location filename="../src/components/AddSourceScreen.qml" line="74"/>
      <source>Add</source>
      <translation>Adicionar</translation>
    </message>
  </context>
  <context>
    <name>AdvancedSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="13"/>
      <source>Updates</source>
      <translation>Atualizações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="16"/>
      <source>Check for updates interval</source>
      <translation>Intervalo para verificar atualizações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Every time</source>
      <translation>Sempre</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a day</source>
      <translation>Diariamente</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a week</source>
      <translation>Semanalmente</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Once a month</source>
      <translation>Mensalmente</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="17"/>
      <source>Never</source>
      <translation>Nunca</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="25"/>
      <source>Backup</source>
      <translation>Backup</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="28"/>
      <source>Export settings</source>
      <translation>Exportar configurações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="29"/>
      <source>Backup the app settings.ini file on your device.</source>
      <translation>Faça o backup do arquivo settings.ini em seu dispositivo.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="37"/>
      <source>Please choose a directory</source>
      <translation>Por favor, escolha uma pasta</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="45"/>
      <source>Import settings</source>
      <translation>Importar configurações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="46"/>
      <source>Import the app settings.ini from an existing file.</source>
      <translation>Importar os parâmetros a partir de um arquivo settings.ini existente.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AdvancedSettingsPage.qml" line="54"/>
      <source>Please choose a file</source>
      <translation>Por favor, escolha um arquivo</translation>
    </message>
  </context>
  <context>
    <name>AppearanceSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="11"/>
      <source>Appearance</source>
      <translation>Aparência</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="14"/>
      <source>Theme</source>
      <translation>Tema</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="21"/>
      <source>Primary color</source>
      <translation>Cor primária</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="26"/>
      <source>Accent color</source>
      <translation>Cor de realce</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="33"/>
      <source>Image</source>
      <translation>Imagem</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="36"/>
      <source>Background color</source>
      <translation>Cor de fundo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceSettingsPage.qml" line="41"/>
      <source>Tags</source>
      <translation>Tags</translation>
    </message>
  </context>
  <context>
    <name>AppearanceTagsSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="11"/>
      <source>Tags</source>
      <translation>Tags</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="14"/>
      <source>Artists</source>
      <translation>Artistas</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="19"/>
      <source>Circle</source>
      <translation>Círculo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="24"/>
      <source>Series</source>
      <translation>Séries</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="29"/>
      <source>Characters</source>
      <translation>Personagens</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="34"/>
      <source>Species</source>
      <translation>Espécies</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="39"/>
      <source>Metas</source>
      <translation>Metadados</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="44"/>
      <source>Models</source>
      <translation>Modelos</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="49"/>
      <source>Generals</source>
      <translation>Gerais</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="54"/>
      <source>Favorites</source>
      <translation>Favoritos</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="59"/>
      <source>Kept for later</source>
      <translation>Manter para mais tarde</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="64"/>
      <source>Blacklisted</source>
      <translation>Lista negra</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/AppearanceTagsSettingsPage.qml" line="69"/>
      <source>Ignored</source>
      <translation>Ignorado</translation>
    </message>
  </context>
  <context>
    <name>BlacklistSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="11"/>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="14"/>
      <source>Blacklist</source>
      <translation>Lista negra</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="15"/>
      <source>One line per blacklist. Multiple tags make an 'AND' condition.</source>
      <translation>Uma linha por lista negra. Múltiplas tags fazem uma condição 'AND'.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="20"/>
      <source>Hide blacklisted</source>
      <translation>Ocultar listados na lista negra</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="21"/>
      <source>Hide blacklisted images from the results.</source>
      <translation>Ocultar imagens com tags na lista negra dos resultados.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="26"/>
      <source>Download blacklisted</source>
      <translation>Fazer download de imagens com tags da lista negra</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="27"/>
      <source>Download blacklisted images during batch downloads.</source>
      <translation>Baixe imagens com tags na lista negra em downloads em lote.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="34"/>
      <source>Tagging</source>
      <translation>Marcação</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="37"/>
      <source>Removed tags</source>
      <translation>Tags removidas</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="38"/>
      <source>These won't be taken into account when saving the image.</source>
      <translation>Estas não serão levadas em conta ao salvar a imagem.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="43"/>
      <source>Ignored tags</source>
      <translation>Tags ignoradas</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/BlacklistSettingsPage.qml" line="44"/>
      <source>One per line. Their tag type will be reset to the default.</source>
      <translation>Um por linha. Seu tipo de tag será redefinido para o padrão.</translation>
    </message>
  </context>
  <context>
    <name>FavoritesScreen</name>
    <message>
      <location filename="../src/components/FavoritesScreen.qml" line="22"/>
      <source>Favorites</source>
      <translation>Favoritos</translation>
    </message>
  </context>
  <context>
    <name>FolderSetting</name>
    <message>
      <location filename="../src/components/settings/items/FolderSetting.qml" line="29"/>
      <source>Please choose a directory</source>
      <translation>Por favor, escolha uma pasta</translation>
    </message>
  </context>
  <context>
    <name>ImageLoader</name>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="155"/>
      <source>File is too big to be displayed.</source>
      <translation>O arquivo é muito grande para ser exibido.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="158"/>
      <source>Image not found.</source>
      <translation>Imagem não encontrada.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="161"/>
      <source>Error loading the image.</source>
      <translation>Erro ao carregar a imagem.</translation>
    </message>
    <message>
      <location filename="../src/loaders/image-loader.cpp" line="164"/>
      <source>Error saving the image.</source>
      <translation>Erro ao salvar a imagem.</translation>
    </message>
  </context>
  <context>
    <name>ImageScreen</name>
    <message>
      <location filename="../src/components/ImageScreen.qml" line="71"/>
      <source>Image</source>
      <translation>Imagem</translation>
    </message>
  </context>
  <context>
    <name>InterfaceSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="11"/>
      <source>Interface</source>
      <translation>Interface</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="14"/>
      <source>Language</source>
      <translation>Idioma</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="23"/>
      <source>Search results</source>
      <translation>Resultados da pesquisa</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="26"/>
      <source>Columns (portrait)</source>
      <translation>Colunas (retrato)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="33"/>
      <source>Columns (landscape)</source>
      <translation>Colunas (paisagem)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="40"/>
      <source>Layout type</source>
      <translation>Tipo de layout</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="47"/>
      <source>Grid ratio</source>
      <translation>Proporção da grade</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="55"/>
      <source>Thumbnail fill mode</source>
      <translation>Modo de preenchimento de miniatura</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="63"/>
      <source>Spaced grid</source>
      <translation>Grade espaçada</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="70"/>
      <source>Rounded grid</source>
      <translation>Grade arredondada</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="71"/>
      <source>Slightly round thumbnails.</source>
      <translation>Miniaturas arredondadas.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="78"/>
      <source>Image viewer</source>
      <translation>Visualizador de imagens</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="81"/>
      <source>Load samples</source>
      <translation>Carregar amostras</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="82"/>
      <source>Load sample-sized versions of the images by default if available.</source>
      <translation>Carregue por padrão as versões de amostra das imagens, se disponível.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="87"/>
      <source>Buttons at the bottom</source>
      <translation>Botão na parte inferior</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="88"/>
      <source>Move the action buttons to the bottom of the screen.</source>
      <translation>Mova os botões de ação para a parte inferior da tela.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="95"/>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="98"/>
      <source>Confirm exit</source>
      <translation>Confirmar saída</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="99"/>
      <source>Show a confirmation dialog before exiting.</source>
      <translation>Mostrar diálogo de confirmação antes de sair.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="104"/>
      <source>Double tap to exit</source>
      <translation>Toque duplo para sair</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/InterfaceSettingsPage.qml" line="105"/>
      <source>Tap back button twice to exit.</source>
      <translation>Toque duas vezes no botão voltar para sair.</translation>
    </message>
  </context>
  <context>
    <name>KeyValueSetting</name>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="63"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="76"/>
      <source>Add</source>
      <translation>Adicionar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="85"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="114"/>
      <source>Key</source>
      <translation>Chave</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="93"/>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="122"/>
      <source>Value</source>
      <translation>Valor</translation>
    </message>
    <message>
      <location filename="../src/components/settings/items/KeyValueSetting.qml" line="105"/>
      <source>Edit</source>
      <translation>Editar</translation>
    </message>
  </context>
  <context>
    <name>LogScreen</name>
    <message>
      <location filename="../src/components/LogScreen.qml" line="18"/>
      <source>Log</source>
      <translation>Registro</translation>
    </message>
  </context>
  <context>
    <name>MainDrawer</name>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="105"/>
      <source>Search</source>
      <translation>Pesquisar</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="111"/>
      <source>Favorites</source>
      <translation>Favoritos</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="117"/>
      <source>Log</source>
      <translation>Log</translation>
    </message>
    <message>
      <location filename="../src/components/MainDrawer.qml" line="141"/>
      <source>Settings</source>
      <translation>Configurações</translation>
    </message>
  </context>
  <context>
    <name>NetworkSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="11"/>
      <source>Proxy</source>
      <translation>Proxy</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="14"/>
      <source>Enable proxy</source>
      <translation>Habilitar proxy</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="19"/>
      <source>Use system-wide proxy settings</source>
      <translation>Usar configurações de proxy do sistema</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="25"/>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="33"/>
      <source>Host</source>
      <translation>Host</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="39"/>
      <source>Port</source>
      <translation>Porta</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="46"/>
      <source>Username</source>
      <translation>Usuário</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/NetworkSettingsPage.qml" line="52"/>
      <source>Password</source>
      <translation>Senha</translation>
    </message>
  </context>
  <context>
    <name>SaveSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="11"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="14"/>
      <source>Folder</source>
      <translation>Pasta</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="19"/>
      <source>Filename</source>
      <translation>Nome do arquivo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="24"/>
      <source>Tags separator</source>
      <translation>Separador de Tags</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="29"/>
      <source>Replace spaces by underscores</source>
      <translation>Substituir espaços por underlines</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="34"/>
      <source>Replace JPEG by JPG</source>
      <translation>Substituir JPEG por JPG</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="35"/>
      <source>If the image's extension is ".jpeg", it will be replaced by ".jpg".</source>
      <translation>Se a extensão da imagem for ".jpeg", ela será substituída por ".jpg".</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="42"/>
      <source>Duplicate management</source>
      <translation>Gerenciamento de duplicados</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="45"/>
      <source>If a file already exists globally</source>
      <translation>Se um arquivo já existe globalmente</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Copy</source>
      <translation>Copiar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Move</source>
      <translation>Mover</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="46"/>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="53"/>
      <source>Don't save</source>
      <translation>Não salvar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="52"/>
      <source>If it's in the same directory</source>
      <translation>Se estiver no mesmo diretório</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="59"/>
      <source>Keep deleted files in the MD5 list</source>
      <translation>Manter arquivos excluídos na lista MD5</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="66"/>
      <source>Tags</source>
      <translation>Tags</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="71"/>
      <source>Artist</source>
      <translation>Artista</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="78"/>
      <source>Copyright</source>
      <translation>Direitos autorais</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="85"/>
      <source>Character</source>
      <translation>Personagem</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="92"/>
      <source>Model</source>
      <translation>Modelo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="99"/>
      <source>Photo set</source>
      <translation>Foto definida</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="106"/>
      <source>Species</source>
      <translation>Espécies</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SaveSettingsPage.qml" line="113"/>
      <source>Meta</source>
      <translation>Metadados</translation>
    </message>
  </context>
  <context>
    <name>SearchScreen</name>
    <message>
      <location filename="../src/components/SearchScreen.qml" line="50"/>
      <source>Search...</source>
      <translation>Pesquisar...</translation>
    </message>
    <message>
      <location filename="../src/components/SearchScreen.qml" line="176"/>
      <source>Sources</source>
      <translation>Fontes</translation>
    </message>
  </context>
  <context>
    <name>SettingsScreen</name>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="31"/>
      <source>Settings</source>
      <translation>Configurações</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="49"/>
      <source>Interface</source>
      <translation>Interface</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="54"/>
      <source>Appearance</source>
      <translation>Aparência</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="59"/>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="64"/>
      <source>Sources</source>
      <translation>Fontes</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="69"/>
      <source>Blacklist</source>
      <translation>Lista negra</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="74"/>
      <source>Network</source>
      <translation>Rede</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="79"/>
      <source>Advanced</source>
      <translation>Avançado</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SettingsScreen.qml" line="84"/>
      <source>About</source>
      <translation>Sobre</translation>
    </message>
  </context>
  <context>
    <name>SourceSettingsScreen</name>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="85"/>
      <source>General</source>
      <translation>Geral</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="88"/>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="97"/>
      <source>HTTPS</source>
      <translation>HTTPS</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="98"/>
      <source>Use a secure connection.</source>
      <translation>Usar uma conexão segura.</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="109"/>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="118"/>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="158"/>
      <source>API order</source>
      <translation>Ordem das APIs</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="167"/>
      <source>Use default API order</source>
      <translation>Usar ordem padrão da API</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="172"/>
      <source>Source 1</source>
      <translation>Fonte 1</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="184"/>
      <source>Source 2</source>
      <translation>Fonte 2</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="196"/>
      <source>Source 3</source>
      <translation>Fonte 3</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="208"/>
      <source>Source 4</source>
      <translation>Fonte 4</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="222"/>
      <source>Download</source>
      <translation>Baixar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="236"/>
      <source>Interval (image)</source>
      <translation>Intervalo (imagem)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="246"/>
      <source>Interval (page)</source>
      <translation>Intervalo (página)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="256"/>
      <source>Interval (details)</source>
      <translation>Intervalo (detalhes)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="266"/>
      <source>Interval (error)</source>
      <translation>Intervalo (erro)</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="278"/>
      <source>Cookies</source>
      <translation>Cookies</translation>
    </message>
    <message>
      <location filename="../src/components/settings/SourceSettingsScreen.qml" line="305"/>
      <source>Headers</source>
      <translation>Cabeçalhos</translation>
    </message>
  </context>
  <context>
    <name>SourcesScreen</name>
    <message>
      <location filename="../src/components/SourcesScreen.qml" line="26"/>
      <source>Sources selection</source>
      <translation>Seleção de fonte</translation>
    </message>
  </context>
  <context>
    <name>SourcesSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="11"/>
      <source>API order</source>
      <translation>Ordem das APIs</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="14"/>
      <source>Source 1</source>
      <translation>Fonte 1</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="21"/>
      <source>Source 2</source>
      <translation>Fonte 2</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="28"/>
      <source>Source 3</source>
      <translation>Fonte 3</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/SourcesSettingsPage.qml" line="35"/>
      <source>Source 4</source>
      <translation>Fonte 4</translation>
    </message>
  </context>
  <context>
    <name>TagSaveSettingsPage</name>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="16"/>
      <source>If empty</source>
      <translation>Se estiver vazio</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="24"/>
      <source>Separator</source>
      <translation>Separador</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="32"/>
      <source>Sort</source>
      <translation>Ordenar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="42"/>
      <source>If more than n tags</source>
      <translation>Se o número de tags for maior que</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="56"/>
      <source>Action</source>
      <translation>Acão</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="63"/>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="72"/>
      <source>Keep n tags</source>
      <translation>Manter esse número de tags</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="81"/>
      <source>Then add</source>
      <translation>Depois adicionar</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="90"/>
      <source>Replace all tags by</source>
      <translation>Substituir todas as tags por</translation>
    </message>
    <message>
      <location filename="../src/components/settings/pages/TagSaveSettingsPage.qml" line="100"/>
      <source>Use shortest if possible</source>
      <translation>Use a tag mais curta, se possível</translation>
    </message>
  </context>
  <context>
    <name>main-screen</name>
    <message>
      <location filename="../src/main-screen.qml" line="47"/>
      <source>Through URL</source>
      <translation>Através da URL</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="48"/>
      <source>HTTP Basic</source>
      <translation>HTTP Básico</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="49"/>
      <source>GET</source>
      <translation>GET</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="50"/>
      <source>POST</source>
      <translation>POST</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="51"/>
      <source>OAuth 1</source>
      <translation>OAuth 1</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="52"/>
      <source>OAuth 2</source>
      <translation>OAuth 2</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="55"/>
      <source>Username</source>
      <translation>Usuário</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="56"/>
      <source>User ID</source>
      <translation>ID do usuário</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="57"/>
      <source>Password</source>
      <translation>Senha</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="58"/>
      <source>Salt</source>
      <translation>Salt</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="59"/>
      <source>API key</source>
      <translation>Chave da API</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="77"/>
      <source>Update available</source>
      <translation>Atualização disponível</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="130"/>
      <source>Do you want to exit?</source>
      <translation>Deseja sair?</translation>
    </message>
    <message>
      <location filename="../src/main-screen.qml" line="144"/>
      <source>Don't ask again</source>
      <translation>Não perguntar novamente</translation>
    </message>
  </context>
</TS>
