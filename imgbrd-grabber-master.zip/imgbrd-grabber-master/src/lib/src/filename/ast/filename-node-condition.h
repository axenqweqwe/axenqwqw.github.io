#ifndef FILENAME_NODE_CONDITION_H
#define FILENAME_NODE_CONDITION_H

#include "filename/ast/filename-node.h"


struct FilenameNodeCondition : public FilenameNode
{};

#endif // FILENAME_NODE_CONDITION_H
