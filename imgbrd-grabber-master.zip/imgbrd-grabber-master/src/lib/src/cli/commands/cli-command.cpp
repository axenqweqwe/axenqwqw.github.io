#include "cli-command.h"
#include <QObject>


CliCommand::CliCommand(QObject *parent)
	: QObject(parent)
{}
