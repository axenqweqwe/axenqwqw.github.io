#include "player.h"


Player::Player(QWidget *parent)
	: QWidget(parent)
{}
