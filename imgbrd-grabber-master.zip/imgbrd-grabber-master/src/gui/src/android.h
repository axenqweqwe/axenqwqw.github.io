#ifndef ANDROID_H
#define ANDROID_H

#include <QString>


bool checkPermission(const QString &perm);

#endif // ANDROID_H
